AUTOFLUX deployment notes

Files:
- index.html: customer storefront at /
- admin.html: admin login/dashboard at /admin.html
- _redirects: Netlify rewrites /admin and /admin/ to admin.html

Deployment:
1. Extract this ZIP.
2. Upload/deploy the contents of this folder to Netlify (not the ZIP file as a single page).
3. Visit your domain root for the storefront and /admin for the admin dashboard.

Important limitations:
- This is a static HTML demo. Products, orders, chats, and hero image settings use localStorage in the browser/device.
- The current admin password is checked in frontend JavaScript, so it is NOT secure for a public production website. Anyone can inspect the source and data is not shared across customer devices. Before using real customer data or taking real orders, connect a secure backend/database and server-side authentication.
- Existing demo password: NovaXMaddy (change/remove this before public deployment; do not rely on it as security).
